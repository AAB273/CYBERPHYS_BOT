# FIXED

Reflectance.obj: C:/Users/wolfm/OneDrive\ -\ University\ of\ Pittsburgh/tirslk_max_1_00_02/inc/Reflectance.c
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
Reflectance.obj: C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
Reflectance.obj: C:/ti/ccs1260/ccs/ccs_base/arm/include/msp432.h
Reflectance.obj: C:/ti/ccs1260/ccs/ccs_base/arm/include/msp432p401r.h
Reflectance.obj: C:/ti/ccs1260/ccs/ccs_base/arm/include/msp_compatibility.h
Reflectance.obj: C:/ti/ccs1260/ccs/ccs_base/arm/include/msp432p401r_classic.h
Reflectance.obj: C:/ti/ccs1260/ccs/ccs_base/arm/include/CMSIS/core_cm4.h
Reflectance.obj: C:/ti/ccs1260/ccs/ccs_base/arm/include/CMSIS/cmsis_compiler.h
Reflectance.obj: C:/ti/ccs1260/ccs/ccs_base/arm/include/CMSIS/cmsis_ccs.h
Reflectance.obj: C:/ti/ccs1260/ccs/ccs_base/arm/include/system_msp432p401r.h
Reflectance.obj: C:/Users/wolfm/OneDrive\ -\ University\ of\ Pittsburgh/tirslk_max_1_00_02/inc/Clock.h

C:/Users/wolfm/OneDrive\ -\ University\ of\ Pittsburgh/tirslk_max_1_00_02/inc/Reflectance.c:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

C:/ti/ccs1260/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

C:/ti/ccs1260/ccs/ccs_base/arm/include/msp432.h:

C:/ti/ccs1260/ccs/ccs_base/arm/include/msp432p401r.h:

C:/ti/ccs1260/ccs/ccs_base/arm/include/msp_compatibility.h:

C:/ti/ccs1260/ccs/ccs_base/arm/include/msp432p401r_classic.h:

C:/ti/ccs1260/ccs/ccs_base/arm/include/CMSIS/core_cm4.h:

C:/ti/ccs1260/ccs/ccs_base/arm/include/CMSIS/cmsis_compiler.h:

C:/ti/ccs1260/ccs/ccs_base/arm/include/CMSIS/cmsis_ccs.h:

C:/ti/ccs1260/ccs/ccs_base/arm/include/system_msp432p401r.h:

C:/Users/wolfm/OneDrive\ -\ University\ of\ Pittsburgh/tirslk_max_1_00_02/inc/Clock.h:

