#include <stdlib.h>
#include <string.h>

#include "driverlib.h"
#include "simplelink.h"
#include "sl_common.h"
#include "MQTTClient.h"



#define SEC_TYPE        SL_SEC_TYPE_WPA_WPA2
#define PASSKEY_LEN     pal_Strlen(PASSKEY)

#define MQTT_BROKER_SERVER  "broker.hivemq.com"

#define BUFF_SIZE           32
#define APPLICATION_VERSION "1.0.0"
#define SL_STOP_TIMEOUT     0xFF
#define SMALL_BUF           32
#define MAX_SEND_BUF_SIZE   512
#define MAX_SEND_RCV_SIZE   1024

typedef enum{
    DEVICE_NOT_IN_STATION_MODE = -0x7D0,
    HTTP_SEND_ERROR = DEVICE_NOT_IN_STATION_MODE - 1,
    HTTP_RECV_ERROR = HTTP_SEND_ERROR - 1,
    HTTP_INVALID_RESPONSE = HTTP_RECV_ERROR - 1,
    STATUS_CODE_MAX = -0xBB8
}e_AppStatusCodes;

#define min(X,Y) ((X) < (Y) ? (X) : (Y))

// Global variables
int rc = 0;
unsigned char buf[100];
unsigned char readbuf[100];
char uniqueID[9];
char macStr[18];
unsigned char macAddressVal[SL_MAC_ADDR_LEN];
unsigned char macAddressLen = SL_MAC_ADDR_LEN;

Network n;
Client hMQTTClient;

_u32 g_Status = 0;
struct{
    _u8 Recvbuff[MAX_SEND_RCV_SIZE];
    _u8 SendBuff[MAX_SEND_BUF_SIZE];
    _u8 HostName[SMALL_BUF];
    _u8 CityName[SMALL_BUF];
    _u32 DestinationIP;
    _i16 SockID;
}g_AppData;

// Forward declarations
static _i32 establishConnectionWithAP();
static _i32 configureSimpleLinkToDefaultState();
static _i32 initializeAppVariables();
static void generateUniqueID();


static void generateUniqueID() {
    CRC32_setSeed(TLV->RANDOM_NUM_1, CRC32_MODE);
    CRC32_set32BitData(TLV->RANDOM_NUM_2);
    CRC32_set32BitData(TLV->RANDOM_NUM_3);
    CRC32_set32BitData(TLV->RANDOM_NUM_4);
    int i;
    for (i = 0; i < 6; i++)
    CRC32_set8BitData(macAddressVal[i], CRC32_MODE);

    uint32_t crcResult = CRC32_getResult(CRC32_MODE);
    sprintf(uniqueID, "%06X", crcResult);
}


// Required SimpleLink event handlers
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvent)
{
    if(pWlanEvent == NULL)
        CLI_Write(" [WLAN EVENT] NULL Pointer Error \n\r");

    switch(pWlanEvent->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
            SET_STATUS_BIT(g_Status, STATUS_BIT_CONNECTION);
            break;

        case SL_WLAN_DISCONNECT_EVENT:
        {
            slWlanConnectAsyncResponse_t* pEventData = NULL;
            CLR_STATUS_BIT(g_Status, STATUS_BIT_CONNECTION);
            CLR_STATUS_BIT(g_Status, STATUS_BIT_IP_ACQUIRED);
            pEventData = &pWlanEvent->EventData.STAandP2PModeDisconnected;
            if(SL_USER_INITIATED_DISCONNECTION == pEventData->reason_code)
                CLI_Write(" Device disconnected from AP on request \n\r");
            else
                CLI_Write(" Device disconnected from AP on ERROR \n\r");
        }
        break;

        default:
            CLI_Write(" [WLAN EVENT] Unexpected event \n\r");
            break;
    }
}

void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    if(pNetAppEvent == NULL)
        CLI_Write(" [NETAPP EVENT] NULL Pointer Error \n\r");

    switch(pNetAppEvent->Event)
    {
        case SL_NETAPP_IPV4_IPACQUIRED_EVENT:
            SET_STATUS_BIT(g_Status, STATUS_BIT_IP_ACQUIRED);
            break;

        default:
            CLI_Write(" [NETAPP EVENT] Unexpected event \n\r");
            break;
    }
}

void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    CLI_Write(" [HTTP EVENT] Unexpected event \n\r");
}

void SimpleLinkGeneralEventHandler(SlDeviceEvent_t *pDevEvent)
{
    CLI_Write(" [GENERAL EVENT] \n\r");
}

void SimpleLinkSockEventHandler(SlSockEvent_t *pSock)
{
    if(pSock == NULL)
        CLI_Write(" [SOCK EVENT] NULL Pointer Error \n\r");

    switch(pSock->Event)
    {
        case SL_SOCKET_TX_FAILED_EVENT:
            switch(pSock->EventData.status)
            {
                case SL_ECLOSE:
                    CLI_Write(" [SOCK EVENT] Close socket operation failed \n\r");
                    break;
                default:
                    CLI_Write(" [SOCK EVENT] Unexpected event \n\r");
                    break;
            }
            break;

        default:
            CLI_Write(" [SOCK EVENT] Unexpected event \n\r");
            break;
    }
}

// Core functions
static _i32 initializeAppVariables()
{
    g_Status = 0;
    pal_Memset(&g_AppData, 0, sizeof(g_AppData));
    return SUCCESS;
}

static _i32 establishConnectionWithAP()
{
    SlSecParams_t secParams = {0};
    _i32 retVal = 0;

    secParams.Key = PASSKEY;
    secParams.KeyLen = PASSKEY_LEN;
    secParams.Type = SEC_TYPE;

    retVal = sl_WlanConnect(SSID_NAME, pal_Strlen(SSID_NAME), 0, &secParams, 0);
    ASSERT_ON_ERROR(retVal);

    while((!IS_CONNECTED(g_Status)) || (!IS_IP_ACQUIRED(g_Status)))
    {
        _SlNonOsMainLoopTask();
    }

    return SUCCESS;
}

static _i32 configureSimpleLinkToDefaultState()
{
    SlVersionFull ver = {0};
    _WlanRxFilterOperationCommandBuff_t RxFilterIdMask = {0};

    _u8  val = 1;
    _u8  configOpt = 0;
    _u8  configLen = 0;
    _u8  power = 0;
    _i32 retVal = -1;
    _i32 mode = -1;

    mode = sl_Start(0, 0, 0);
    ASSERT_ON_ERROR(mode);

    if(ROLE_STA != mode)
    {
        if(ROLE_AP == mode)
            while(!IS_IP_ACQUIRED(g_Status)) { _SlNonOsMainLoopTask(); }

        retVal = sl_WlanSetMode(ROLE_STA);
        ASSERT_ON_ERROR(retVal);

        retVal = sl_Stop(SL_STOP_TIMEOUT);
        ASSERT_ON_ERROR(retVal);

        retVal = sl_Start(0, 0, 0);
        ASSERT_ON_ERROR(retVal);

        if(ROLE_STA != retVal)
            ASSERT_ON_ERROR(DEVICE_NOT_IN_STATION_MODE);
    }

    configOpt = SL_DEVICE_GENERAL_VERSION;
    configLen = sizeof(ver);
    retVal = sl_DevGet(SL_DEVICE_GENERAL_CONFIGURATION, &configOpt, &configLen, (_u8 *)(&ver));
    ASSERT_ON_ERROR(retVal);

    retVal = sl_WlanPolicySet(SL_POLICY_CONNECTION, SL_CONNECTION_POLICY(1, 0, 0, 0, 1), NULL, 0);
    ASSERT_ON_ERROR(retVal);

    retVal = sl_WlanProfileDel(0xFF);
    ASSERT_ON_ERROR(retVal);

    retVal = sl_WlanDisconnect();
    if(0 == retVal)
        while(IS_CONNECTED(g_Status)) { _SlNonOsMainLoopTask(); }

    retVal = sl_NetCfgSet(SL_IPV4_STA_P2P_CL_DHCP_ENABLE, 1, 1, &val);
    ASSERT_ON_ERROR(retVal);

    configOpt = SL_SCAN_POLICY(0);
    retVal = sl_WlanPolicySet(SL_POLICY_SCAN, configOpt, NULL, 0);
    ASSERT_ON_ERROR(retVal);

    power = 0;
    retVal = sl_WlanSet(SL_WLAN_CFG_GENERAL_PARAM_ID, WLAN_GENERAL_PARAM_OPT_STA_TX_POWER, 1, (_u8 *)&power);
    ASSERT_ON_ERROR(retVal);

    retVal = sl_WlanPolicySet(SL_POLICY_PM, SL_NORMAL_POLICY, NULL, 0);
    ASSERT_ON_ERROR(retVal);

    retVal = sl_NetAppMDNSUnRegisterService(0, 0);
    ASSERT_ON_ERROR(retVal);

    pal_Memset(RxFilterIdMask.FilterIdMask, 0xFF, 8);
    retVal = sl_WlanRxFilterSet(SL_REMOVE_RX_FILTER, (_u8 *)&RxFilterIdMask,
                                sizeof(_WlanRxFilterOperationCommandBuff_t));
    ASSERT_ON_ERROR(retVal);

    retVal = sl_Stop(SL_STOP_TIMEOUT);
    ASSERT_ON_ERROR(retVal);

    retVal = initializeAppVariables();
    ASSERT_ON_ERROR(retVal);

    return retVal;
}

void MQTT_Init(void)
{
    P1->DIR |= 0x01;   // red LED output
    P2->DIR |= 0x02;   // green LED output

    _i32 retVal = -1;
    retVal = initializeAppVariables();

    stopWDT();
    initClk();
    CLI_Configure();

    P1->OUT |= 0x01;   // red ON = reached configureSimpleLink

    retVal = configureSimpleLinkToDefaultState();
    if(retVal < 0) { LOOP_FOREVER(); }

    P1->OUT &= ~0x01;  // red OFF = configureSimpleLink passed

    retVal = sl_Start(0, 0, 0);
    if((retVal < 0) || (ROLE_STA != retVal)) { LOOP_FOREVER(); }

    P2->OUT |= 0x02;   // green ON = sl_Start passed

    retVal = establishConnectionWithAP();
    if(retVal < 0) { LOOP_FOREVER(); }

    P2->OUT &= ~0x02;  // green OFF = AP connected

    sl_NetCfgGet(SL_MAC_ADDRESS_GET, NULL, &macAddressLen, (unsigned char *)macAddressVal);
    snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x",
            macAddressVal[0], macAddressVal[1], macAddressVal[2],
            macAddressVal[3], macAddressVal[4], macAddressVal[5]);
    generateUniqueID();

    NewNetwork(&n);
    rc = ConnectNetwork(&n, MQTT_BROKER_SERVER, 1883);

    if(rc != 0) {
        CLI_Write(" Failed to connect to MQTT broker \n\r");
        LOOP_FOREVER();
    }

    MQTTClient(&hMQTTClient, &n, 1000, buf, 100, readbuf, 100);
    MQTTPacket_connectData cdata = MQTTPacket_connectData_initializer;
    cdata.MQTTVersion = 3;
    cdata.clientID.cstring = uniqueID;
    rc = MQTTConnect(&hMQTTClient, &cdata);
    if(rc != 0) {
        CLI_Write(" Failed to start MQTT client \n\r");
        LOOP_FOREVER();
    }
}

void MQTT_Send(char* message, char* publish_topic)
{
    MQTTYield(&hMQTTClient, 10);

    MQTTMessage msg;
    msg.dup = 0;
    msg.id = 0;
    msg.payload = message;
    msg.payloadlen = strlen(message);
    msg.qos = QOS0;
    msg.retained = 0;

    rc = MQTTPublish(&hMQTTClient, publish_topic, &msg);
    if(rc != 0) {
        CLI_Write(" Failed to publish message \n\r");
    }
}
