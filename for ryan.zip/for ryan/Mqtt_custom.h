#ifndef MQTT_CUSTOM_H
#define MQTT_CUSTOM_H

void MQTT_Init(void);
void MQTT_Send(char* message, char* topic);

#endif
